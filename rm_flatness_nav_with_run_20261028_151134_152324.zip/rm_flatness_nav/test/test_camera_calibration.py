"""Recover known intrinsics from synthetic views and validate ROS YAML layout."""
import unittest
import cv2
import numpy as np
from rm_flatness_nav.calibrate_camera import board_points, calibrate, calibration_yaml


class CalibrationTests(unittest.TestCase):
    def test_recovers_intrinsics_and_driver_yaml(self):
        matrix = np.array([[520., 0., 320.], [0., 515., 180.], [0., 0., 1.]])
        objects = board_points(9, 6, .025)
        rng = np.random.default_rng(42)
        views = []
        for _ in range(20):
            rotation = rng.uniform(-.45, .45, 3)
            translation = np.array([rng.uniform(-.15, .03), rng.uniform(-.12, .01), rng.uniform(.5, .9)])
            points, _ = cv2.projectPoints(objects, rotation, translation, matrix, np.zeros(5))
            views.append(points)
        rms, fitted, distortion, errors = calibrate(views, (640, 360), 9, 6, .025)
        self.assertLess(rms, .001)
        np.testing.assert_allclose(fitted, matrix, atol=.02)
        self.assertEqual(len(errors), 20)
        data = calibration_yaml((640, 360), fitted, distortion)
        self.assertEqual(data['image_width'], 640)
        self.assertEqual(data['image_height'], 360)
        self.assertEqual(data['distortion_model'], 'plumb_bob')
        self.assertEqual(len(data['camera_matrix']['data']), 9)
        self.assertEqual(len(data['projection_matrix']['data']), 12)
        self.assertEqual(data['distortion_coefficients']['cols'], 5)
        self.assertEqual(data['rectification_matrix']['data'], np.eye(3).ravel().tolist())

    def test_rejects_insufficient_samples(self):
        with self.assertRaisesRegex(ValueError, '15'):
            calibrate([], (640, 360), 9, 6, .025)
