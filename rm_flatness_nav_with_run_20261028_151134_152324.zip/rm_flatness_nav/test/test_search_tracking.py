import csv
import math
import tempfile
import unittest
from pathlib import Path
from rm_flatness_nav.search_cycle import SearchCycle
from rm_flatness_nav.tracking_log import TrackingLog
from rm_flatness_nav.flatness import FlatTrajectory
from rm_flatness_nav.state_machine import NavStateMachine, Observation, ARRIVED


class SearchAndTrackingTests(unittest.TestCase):
    def test_full_turn_each_direction_then_five_second_move(self):
        for direction in (-1, 1):
            cycle = SearchCycle()
            for i in range(127):
                angle = direction * i * .05
                yaw = math.atan2(math.sin(angle), math.cos(angle))
                command = cycle.command(yaw, direction*.15, i*.05)
                self.assertEqual(command, (.1, 0.) if i == 126 else (0., direction*.15))
            start = 126*.05
            for offset in (0.05, 1., 2., 4.95):
                self.assertEqual(cycle.command(yaw, direction*.15, start+offset), (.1, 0.))
            self.assertEqual(cycle.command(yaw, direction*.15, start+5.), (0., direction*.15))
            self.assertIsNone(cycle.forward_until)
            # A second complete turn triggers the same five-second move.
            for i in range(1, 127):
                angle = direction * (126+i)*.05
                yaw = math.atan2(math.sin(angle), math.cos(angle))
                command = cycle.command(yaw, direction*.15, start+5.+i*.05)
            self.assertEqual(command, (.1, 0.))

    def test_reversal_is_not_a_full_turn(self):
        cycle = SearchCycle()
        for step, i in enumerate(list(range(61)) + list(range(60,-1,-1))):
            self.assertEqual(cycle.command(i*.05,.15,step*.05)[0],0.)
        cycle.reset()
        self.assertEqual(cycle.command(0.,.15,10.),(0.,.15))

    def test_reset_cancels_forward_motion(self):
        cycle = SearchCycle()
        cycle.forward_until = 10.
        cycle.reset()
        self.assertEqual(cycle.command(0., .15, 2.), (0., .15))

    def test_chase_respects_requested_speed_band(self):
        fsm = NavStateMachine()
        fsm.traj = FlatTrajectory(2., v_max=fsm.p.v_max)
        fsm.traj_t0 = 0.
        v, _ = fsm._chase(Observation(now=fsm.traj.T / 2, visible=True, distance=2.))
        self.assertGreaterEqual(v, .14)
        self.assertLessEqual(v, .16)
        v, _ = fsm._chase(Observation(now=fsm.traj.T / 2, visible=True, distance=.21))
        self.assertAlmostEqual(v, .14)

    def test_arrival_is_permanent(self):
        fsm=NavStateMachine()
        fsm.check_target_width(True,.17,0.,0.,tof=.19)
        for i in range(100):
            self.assertEqual(fsm.update(Observation(now=i)),(0.,0.))
            self.assertEqual(fsm.state,ARRIVED)

    def test_csv_plots_and_cubic_reference(self):
        with tempfile.TemporaryDirectory() as folder:
            log=TrackingLog(folder)
            traj=FlatTrajectory(1.)
            log.record(0.,'CHASING',(1.,2.,math.pi/2),(.05,0.),(.06,0.),.1,traj,0.)
            log.record(1.,'CHASING',(1.,2.05,math.pi/2),(.05,0.),(.1,0.),.12,traj,1.)
            log.record(2.,'ARRIVED',(1.,2.15,math.pi/2),(0.,0.),(0.,0.),.15)
            log.finish()
            log.finish()
            for name in ('tracking.csv','path.png','velocity.png','tracking_errors.png'):
                self.assertGreater((Path(folder)/name).stat().st_size,100)
            with (Path(folder)/'tracking.csv').open() as stream:
                rows=list(csv.DictReader(stream))
            self.assertEqual(len(rows),3)
            self.assertAlmostEqual(float(rows[1]['planned_x_m']),1.)
            self.assertAlmostEqual(float(rows[1]['planned_y_m']),2.+traj.sample(1.)[2])
            self.assertEqual(float(rows[-1]['ref_v_mps']),0.)


if __name__=='__main__':
    unittest.main()
