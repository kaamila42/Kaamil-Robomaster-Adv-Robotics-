"""Final approach skips alignment; ToF independently triggers braking."""
import unittest
from rm_flatness_nav.state_machine import NavStateMachine, Observation, ARRIVED, CHASING, HOLD


class WidthPriorityTests(unittest.TestCase):
    def test_braking_distance_independent_of_width(self):
        for width in (.15, .16, .169, .17, .171, .25):
            for tof in (None, float('nan'), float('inf'), 0., -.1, .19, .20, .21):
                with self.subTest(width=width, tof=tof):
                    fsm = NavStateMachine()
                    expected_state = ARRIVED if width >= .17 else (HOLD if tof in (.19, .20) else None)
                    expected = expected_state is not None
                    self.assertEqual(fsm.check_target_width(True, width, 100., 100., tof=tof), expected)
                    if expected_state:
                        self.assertEqual(fsm.state, expected_state)
                    if expected:
                        self.assertEqual(fsm.update(Observation(now=1.)), (0., 0.))
                        self.assertEqual(fsm.state, expected_state)

    def test_final_approach_ignores_crosshair_and_camera_distance(self):
        for width in (.1501, .16, .169):
            fsm = NavStateMachine()
            command = fsm.update(Observation(now=0., visible=True, observed_at=0.,
                bearing=.8, distance=.05, tof=.3, bbox_w_fraction=width,
                center_x_error=100., center_y_error=100.))
            self.assertEqual(command, (.14, 0.))
            self.assertEqual(fsm.state, CHASING)

    def test_alignment_still_runs_at_fifteen_percent(self):
        fsm = NavStateMachine()
        v, w = fsm.update(Observation(now=0., visible=True, observed_at=0.,
            bearing=.8, distance=1., tof=.3, bbox_w_fraction=.15))
        self.assertEqual(v, 0.)
        self.assertNotEqual(w, 0.)

    def test_chase_stops_on_lost_detection(self):
        fsm = NavStateMachine()
        fsm.update(Observation(now=0., visible=True, observed_at=0.,
            bbox_w_fraction=.16, tof=.3))
        self.assertEqual(fsm.update(Observation(now=.1)), (0., 0.))
        self.assertTrue(fsm.check_target_width(False, .20, tof=.19))

    def test_brake_is_not_arrival_and_requires_clear_range_to_release(self):
        fsm = NavStateMachine()
        self.assertTrue(fsm.check_target_width(True, .16, tof=.20))
        self.assertEqual(fsm.state, HOLD)
        self.assertTrue(fsm.check_target_width(True, .16, tof=None))
        self.assertFalse(fsm.check_target_width(True, .16, tof=.25))
        self.assertTrue(fsm.check_target_width(True, .17, tof=None))
        self.assertEqual(fsm.state, ARRIVED)

    def test_update_arrives_without_crosshair_alignment(self):
        fsm = NavStateMachine()
        self.assertEqual(fsm.update(Observation(now=0., visible=True,
            bbox_w_fraction=.17, tof=.19, center_x_error=100.)), (0., 0.))
        self.assertEqual(fsm.state, ARRIVED)


if __name__ == '__main__':
    unittest.main()
