import importlib.util
from unittest.mock import patch
from pathlib import Path
import yaml
from launch import LaunchService, LaunchDescription
from launch.actions import ExecuteProcess
from launch.utilities import perform_substitutions

p=Path(__file__).resolve().parents[1] / 'launch/assessment2.launch.py'
spec=importlib.util.spec_from_file_location('assessment_launch',p)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
commands=[]
def dry_execute(self, context):
    cmd=[perform_substitutions(context, item) for item in self.cmd]
    commands.append(cmd)
    return []
service=LaunchService(noninteractive=True)
service.include_launch_description(m.generate_launch_description())
with patch.object(ExecuteProcess,'execute',dry_execute):
    code=service.run()
assert code==0, code
names=[]
for command in commands:
    if len(command) > 1 and Path(command[1]).name == 'robomaster_driver':
        assert command[0] == str(Path.home() / 'rm_venv/bin/python3'), command
        command = command[1:]
    names.append(Path(command[0]).name)
    print('RESOLVED EXECUTABLE:',command[0])
    if Path(command[0]).name=='robomaster_driver':
        files=[command[i+1] for i,arg in enumerate(command[:-1]) if arg=='--params-file']
        values={}
        for file in files:
            data=yaml.safe_load(Path(file).read_text())
            for node in data.values():values.update(node.get('ros__parameters',{}))
        assert values['conn_type']=='ap', values
        assert values['tof.enabled'] is True, values
        assert values['camera.enabled'] is True, values
        assert values['camera.video.raw']==1, values
        assert values['arm.enabled'] is True, values
        calibration = Path(values['camera.video.calibration_file'])
        assert calibration == Path.home() / 'ros2_ws/src/rm_flatness_nav/config/camera_calibration.yaml', calibration
        assert calibration.is_file(), calibration
        print('DRIVER: AP, ToF, camera raw, arm parameters verified')
assert {'robomaster_driver','image_view','robot_state_publisher','joint_state_publisher'}<=set(names),names
assert any(command[1:4] == ['-u', '-m', 'rm_flatness_nav.nav_node']
           for command in commands), commands
print('PASS: complete launch evaluated; no processes or hardware connections started')
