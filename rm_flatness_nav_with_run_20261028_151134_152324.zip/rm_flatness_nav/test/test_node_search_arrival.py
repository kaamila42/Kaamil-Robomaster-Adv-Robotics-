"""Offline integration using real ROS message types and mocked transports."""
import math
import tempfile
import unittest
from contextlib import ExitStack
from types import SimpleNamespace as NS
from unittest.mock import MagicMock, patch
from rclpy.node import Node
from geometry_msgs.msg import PointStamped
from sensor_msgs.msg import Image
from rm_flatness_nav import nav_node
from rm_flatness_nav.state_machine import ARRIVED, SEARCHING, ALIGNING, NavStateMachine


class NodeSearchTests(unittest.TestCase):
    def test_camera_health_counts_throttled_frames_and_rejects_stale_frames(self):
        node = NS(now=lambda: 100.06, camera_timeout=1.,
                  process_interval=.08, last_processed=100., camera_time=99.,
                  get_logger=lambda: MagicMock(), bridge=MagicMock())
        msg = Image()
        msg.header.stamp.sec = 100
        msg.header.stamp.nanosec = 50000000
        nav_node.FlatnessNav.on_image(node, msg)
        self.assertAlmostEqual(node.camera_time, 100.05)
        self.assertEqual(node.last_processed, 100.)
        node.bridge.imgmsg_to_cv2.assert_not_called()
        msg.header.stamp.sec = 98
        nav_node.FlatnessNav.on_image(node, msg)
        self.assertAlmostEqual(node.camera_time, 100.05)
        msg.header.stamp.sec = 102
        nav_node.FlatnessNav.on_image(node, msg)
        self.assertAlmostEqual(node.camera_time, 100.05)

    def test_camera_health_has_separate_timeout(self):
        publisher = MagicMock()
        publisher.get_subscription_count.return_value = 1
        node = NS(fsm=NavStateMachine(), K=object(), tf_ok=True,
                  camera_time=99.4, camera_timeout=1., odom_time=100.,
                  cmd_pub=publisher)
        self.assertTrue(nav_node.FlatnessNav.interfaces_ready(node, 100.))
        node.camera_time = 98.9
        self.assertFalse(nav_node.FlatnessNav.interfaces_ready(node, 100.))
        node.camera_time = 100.
        node.odom_time = 99.
        self.assertFalse(nav_node.FlatnessNav.interfaces_ready(node, 100.))

    def test_five_second_advance_then_search_and_permanent_arrival(self):
        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            clock=NS(value=100.)
            publisher=MagicMock()
            publisher.get_subscription_count.return_value=1
            params={'csv_path':directory+'/slow.csv', 'fast_csv_path':directory+'/fast.csv',
                    'output_dir':directory+'/tracking', 'generate_plots':False}
            stack.enter_context(patch.object(Node,'__init__',return_value=None))
            stack.enter_context(patch.object(Node,'declare_parameter',lambda self,k,d:NS(value=params.get(k,d))))
            stack.enter_context(patch.object(Node,'create_publisher',return_value=publisher))
            stack.enter_context(patch.object(Node,'create_subscription'))
            stack.enter_context(patch.object(Node,'create_timer'))
            stack.enter_context(patch.object(Node,'get_logger',return_value=MagicMock()))
            stack.enter_context(patch.object(nav_node.FlatnessNav,'now',lambda self:clock.value))
            stack.enter_context(patch.object(nav_node.tf2_ros,'Buffer'))
            stack.enter_context(patch.object(nav_node.tf2_ros,'TransformListener'))
            stack.enter_context(patch.object(nav_node,'ActionClient'))
            node=nav_node.FlatnessNav()
            # Arm setup must not wait for any sensor or odometry messages.
            node.arm_client.server_is_ready.return_value = True
            node.tick()
            node.arm_client.send_goal_async.assert_not_called()
            initial = PointStamped()
            initial.header.frame_id = 'arm_base_link'
            node.on_arm(initial)
            node.tick()
            goal = node.arm_client.send_goal_async.call_args.args[0]
            self.assertAlmostEqual(goal.x, .105, places=6)
            self.assertAlmostEqual(goal.z, .080, places=6)
            self.assertFalse(goal.relative)
            self.assertTrue(node.arm_sent)
            feedback = PointStamped()
            feedback.header.frame_id = 'arm_base_link'
            feedback.point.x = .103
            feedback.point.z = .079
            node.arm_succeeded = False
            node.on_arm(feedback)
            self.assertTrue(node.arm_verified)
            feedback.point.x = .100
            node.on_arm(feedback)
            self.assertFalse(node.arm_verified)
            feedback.point.x = float('nan')
            node.on_arm(feedback)
            self.assertFalse(node.arm_verified)
            node.interfaces_ready=lambda now:True
            node.zero_sent=True
            node.arm_verified=True
            node.arm_failed=True
            pulses=0
            for i in range(230):
                clock.value=100+i*.05
                node.arm_time=clock.value
                yaw=math.atan2(math.sin(i*.05),math.cos(i*.05))
                node.odom_pose=(0.,0.,yaw)
                node.tick()
                if node.v_cmd:
                    pulses+=1
                    self.assertEqual((node.v_cmd,node.w_cmd),(.1,0.))
                self.assertEqual(node.fsm.state,SEARCHING)
            self.assertEqual(pulses,100)
            # Waiting beyond 60 seconds cannot override search with straight driving.
            clock.value += 61.
            node.arm_time = clock.value
            node.tick()
            self.assertEqual(node.v_cmd, 0.)
            self.assertNotEqual(node.w_cmd, 0.)
            # A tag detected during the next advance cancels it for alignment.
            node.search_cycle.forward_until = clock.value + 5.
            node.detection_time = clock.value
            node.target_distance = 1.
            node.target_bearing = .5
            node.bbox_w = .1
            node.tick()
            self.assertEqual(node.fsm.state, ALIGNING)
            self.assertEqual(node.v_cmd, 0.)
            self.assertIsNone(node.search_cycle.forward_until)
            node.fsm.check_target_width(True,.17,0.,0.,tof=.19)
            for i in range(10):
                clock.value+=.05
                node.arm_time=clock.value
                node.tick()
                msg=publisher.publish.call_args.args[0]
                self.assertEqual((msg.linear.x,msg.angular.z),(0.,0.))
                self.assertEqual(node.fsm.state,ARRIVED)
            self.assertTrue(node.completed)
            node.fsm._enter_search()
            self.assertEqual(node.fsm.state,ARRIVED)
            node.shutdown()


if __name__=='__main__':
    unittest.main()
