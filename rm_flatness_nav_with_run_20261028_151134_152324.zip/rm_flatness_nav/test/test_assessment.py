#!/usr/bin/env python3
"""Offline regressions: real algorithms/messages; mocked ROS transport only."""
import csv
import importlib.util
import math
from pathlib import Path
from contextlib import ExitStack
from types import SimpleNamespace as NS
from unittest import TestCase, main
from unittest.mock import MagicMock, patch
import tempfile

import cv2
import numpy as np
from geometry_msgs.msg import PointStamped
from sensor_msgs.msg import CameraInfo, Image, Range
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rm_flatness_nav.flatness import FlatTrajectory, eval_cubic, flat_inversion, time_horizon
from rm_flatness_nav.wheel_voltage import wheel_rates, MotorVoltageModel
from rm_flatness_nav.state_machine import *
from rm_flatness_nav import nav_node
from rm_flatness_nav.tag_detector import TagDetector, R_OPTICAL_TO_BASE, ground_range_bearing

ROOT = Path(__file__).resolve().parents[1]


def marker_image(tag_id=3):
    dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_APRILTAG_36h11)
    if hasattr(cv2.aruco, 'generateImageMarker'):
        marker = cv2.aruco.generateImageMarker(dictionary, tag_id, 160)
    else:
        marker = cv2.aruco.drawMarker(dictionary, tag_id, 160)
    image = np.full((480, 640), 255, np.uint8)
    image[160:320, 240:400] = marker
    return image


class AssessmentTests(TestCase):
    def test_cubic_boundaries_and_speed(self):
        for d in (0.21, 0.4, 1.0, 2.0, 4.0):
            t = FlatTrajectory(d)
            np.testing.assert_allclose(eval_cubic(t.alpha_x, 0)[:2], [0, .06], atol=1e-12)
            np.testing.assert_allclose(eval_cubic(t.alpha_x, t.T)[:2], [d-.2, 0], atol=1e-12)
            np.testing.assert_allclose(t.alpha_y, 0)
            self.assertEqual(t.T, max(4., 1.6*(d-.2)/.16))
            self.assertTrue(all(t.sample(x)[0] <= .16 + 1e-10 for x in np.linspace(0, t.T, 100)))
        self.assertEqual(flat_inversion(0, 0, 1, 1), (0, 0))
        np.testing.assert_allclose(flat_inversion(1, 2, 3, 4), [math.sqrt(5), -.4])

    def test_motor_model(self):
        np.testing.assert_allclose(wheel_rates(.16, .3), [4.4, 2, 2, 4.4])
        model = MotorVoltageModel()
        np.testing.assert_allclose(model.step(wheel_rates(0, 0), .05), [0]*4)
        np.testing.assert_allclose(model.step(wheel_rates(.16, .3), .05), [6.952, 3.16, 3.16, 6.952])
        np.testing.assert_allclose(model.step([0]*4, .05), [-5.28, -2.4, -2.4, -5.28])

    def test_fsm_alignment_loss_and_search_direction(self):
        f = NavStateMachine()
        self.assertEqual(f.update(Observation(0)), (0, .3))
        self.assertEqual(f.update(Observation(.1, True, -.5, 1.))[0], 0)
        self.assertEqual(f.state, ALIGNING)
        f.update(Observation(.2, True, 0, 1.))
        self.assertAlmostEqual(f.update(Observation(.51, True, 0, 1.))[0], .06)
        self.assertEqual(f.state, CHASING)
        f.update(Observation(.6, True, 0, 1., observed_at=.51))
        self.assertEqual(f.update(Observation(.961)), (0, -.3))
        self.assertEqual(f.state, SEARCHING)

    def test_arrival_and_trajectory_expiry(self):
        for obs in (Observation(0, True, 0, .2), Observation(0, tof=.19)):
            f = NavStateMachine()
            self.assertEqual(f.update(obs), (0, 0));self.assertEqual(f.state, ARRIVED)
            self.assertEqual(f.update(Observation(1)), (0, 0))
        f = NavStateMachine()
        f.update(Observation(0, True, 0, 1))
        f.update(Observation(.31, True, 0, 1))
        f.update(Observation(20, True, 0, .4))
        self.assertEqual(f.state, CHASING)  # time alone must not declare arrival

    def test_aruco_tag3_pose_and_wrong_id(self):
        k = np.array([[600., 0, 320], [0, 600., 240], [0, 0, 1]])
        detector = TagDetector()
        result = detector.detect(marker_image(), k)
        self.assertIsNotNone(result)
        self.assertEqual(result.tag_id, 3)
        self.assertAlmostEqual(result.tvec[2], .15*600/160, delta=.02)
        self.assertIsNone(detector.detect(marker_image(4), k))
        d, b = ground_range_bearing([-.1, 0, 1], R_OPTICAL_TO_BASE)
        self.assertAlmostEqual(d, math.hypot(1, .1));self.assertGreater(b, 0)

    def test_node_sensors_gating_arm_braking_csv(self):
        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            clock = NS(value=100.)
            logger = MagicMock()
            publisher = MagicMock();publisher.get_subscription_count.return_value = 1
            params = {'csv_path': directory+'/slow.csv', 'fast_csv_path': directory+'/fast.csv'}
            def declare(node, key, default):
                return NS(value=params.get(key, default))
            stack.enter_context(patch.object(Node, '__init__', return_value=None))
            stack.enter_context(patch.object(Node, 'declare_parameter', declare))
            stack.enter_context(patch.object(Node, 'create_publisher', return_value=publisher))
            stack.enter_context(patch.object(Node, 'create_subscription'))
            stack.enter_context(patch.object(Node, 'create_timer'))
            stack.enter_context(patch.object(Node, 'get_logger', return_value=logger))
            stack.enter_context(patch.object(nav_node.FlatnessNav, 'now', lambda self: clock.value))
            stack.enter_context(patch.object(nav_node.tf2_ros, 'Buffer'))
            stack.enter_context(patch.object(nav_node.tf2_ros, 'TransformListener'))
            stack.enter_context(patch.object(nav_node, 'ActionClient'))
            node = nav_node.FlatnessNav()
            self.assertEqual(node.tag_size, .15)
            node.tick()
            self.assertEqual(publisher.publish.call_args.args[0].angular.z, 0)
            node.arm_client.send_goal_async.assert_not_called()
            info = CameraInfo()
            info.k = [600., 0., 320., 0., 600., 240., 0., 0., 1.]
            info.header.frame_id = 'camera_optical_link'
            node.on_info(info)
            node.on_range(Range(range=1., min_range=.1, max_range=10.))
            node.on_odom(Odometry())
            node.image_time = clock.value;node.tf_ok = True
            node.tick()
            goal = node.arm_client.send_goal_async.call_args.args[0]
            self.assertAlmostEqual(goal.x, .105, places=6)
            self.assertAlmostEqual(goal.z, .080, places=6)
            self.assertFalse(goal.relative)
            self.assertEqual(int(float(np.float32(goal.x))*1000), 105)
            self.assertEqual(int(float(np.float32(goal.z))*1000), 80)
            self.assertEqual(node.v_cmd, 0)
            node.arm_succeeded = True
            arm = PointStamped();arm.header.frame_id = 'arm_base_link'
            arm.point.x=.105;arm.point.z=.030
            node.on_arm(arm);self.assertFalse(node.arm_verified)
            arm.point.z=.080;node.on_arm(arm);self.assertTrue(node.arm_verified)
            node.r_bc = R_OPTICAL_TO_BASE
            node.process_frame(marker_image())
            self.assertLess(abs(node.bearing), .02)
            node.tick();self.assertEqual(node.fsm.state, ALIGNING)
            clock.value += .31
            node.on_info(info);node.on_arm(arm);node.on_odom(Odometry())
            node.on_range(Range(range=1., max_range=10.))
            node.image_time=clock.value;node.process_frame(marker_image())
            node.tick();self.assertEqual(node.fsm.state, CHASING)
            self.assertGreater(node.v_cmd, 0)
            # Drop sensor freshness: stop immediately and abandon the trajectory.
            clock.value += .46
            node.tick();self.assertEqual((node.v_cmd, node.w_cmd), (0,0))
            self.assertEqual(node.fsm.state, SEARCHING)
            node.on_info(info);node.on_arm(arm);node.on_odom(Odometry())
            node.image_time=clock.value
            node.on_range(Range(range=.19, max_range=10.))
            node.tick();self.assertEqual(node.fsm.state, ARRIVED)
            node.tick();node.tick()
            self.assertTrue(node.finished)
            node.shutdown()
            with open(params['csv_path']) as f:
                rows=list(csv.DictReader(f))
            self.assertTrue(any('BRAKING' in row['state'] for row in rows))
            self.assertTrue(rows[-1]['state'].startswith('ARRIVED'))
            with open(params['fast_csv_path']) as f:
                self.assertGreater(len(list(csv.DictReader(f))), 3)
            node.arm_client.send_goal_async.assert_called_once()

    def test_merged_reference_import(self):
        spec = importlib.util.spec_from_file_location('merged_assessment', ROOT/'rm_flatness_nav_single.py')
        module = importlib.util.module_from_spec(spec)
        import sys
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        np.testing.assert_allclose(module.wheel_rates(.16,.3), wheel_rates(.16,.3))
        self.assertEqual(module.NavStateMachine().update(module.Observation(0)), (0,.3))


if __name__ == '__main__':
    main(verbosity=2)
