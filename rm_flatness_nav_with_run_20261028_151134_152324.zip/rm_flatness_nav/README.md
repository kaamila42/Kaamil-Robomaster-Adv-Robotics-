## Current search, arrival, and tracking behavior

Tag 3 above **15% of image width** disables crosshair alignment and starts
straight final approach at 0.14 m/s. **Width >=17% declares ARRIVED** and
permanently stops motion, independently of ToF and crosshair alignment.
Separately, fresh valid **ToF <=0.20 m brakes into HOLD**, without declaring
arrival if width is below 17%. HOLD remains until a fresh reading exceeds
20 cm or width reaches 17%; missing ToF does not release braking. ToF must
point at the tag surface to measure the distance before the tag. The node
publishes zero Twist after ARRIVED until shutdown; restart the launch for
another run. Chase speeds remain 0.14–0.16 m/s; the 60-second fallback is removed.

Camera input keeps only the latest frame. Stream health uses `camera_timeout_s`
(default 1.0 s), independently of the 0.45 s tag-loss timeout. Chase commands
still stop when the target observation is older than 0.20 s. Stale-camera
warnings include the last frame age to distinguish a stream gap from tag loss.

While SEARCHING, wrapped odometry yaw increments measure a full signed turn
in either direction. A full turn without alignment triggers 5 seconds of forward
motion at 0.1 m/s (0.5 m of commanded travel), then another full search turn.
Detecting Tag 3 interrupts translation and starts alignment immediately. Reversing
back to the start before completing a full turn does not trigger a step. Sensor
or arm readiness loss cancels the accumulated search turn. No step bypasses
motion disable, arm readiness, or arrival.

Launch normally:

```bash
ros2 launch rm_flatness_nav assessment2.launch.py enable_motion:=true
```

Each launch creates `~/ros2_ws/log/assessment2/run_<timestamp>/tracking.csv`.
It contains planned/actual position and heading, commanded/measured linear and
angular velocities, tracking errors (reference minus actual), state, and width.
Actual motion comes from odometry. During chasing, the planned reference is the
cubic trajectory transformed into the odometry frame at each trajectory start;
during search and alignment it is integrated commanded motion. This is a local
reference, not an obstacle-aware global planner.

On ARRIVED or Ctrl+C, the run directory receives `path.png`, `velocity.png`, and
`tracking_errors.png`, plus separate `reference_velocity.png`,
`reference_position.png`, `actual_position.png`, and `planned_path.png`.
Plots are saved without a display window. Set
`output_dir:=/absolute/path` to choose a directory or `generate_plots:=false`
to keep only CSV output. A timestamped directory is recommended to preserve runs.
The older motor voltage CSV files remain available in the assessment2 directory.

# SCE 672 Assessment 2 — RoboMaster EP Core

Baseline: `/home/kaamil/Downloads/rm_flatness_nav_single.py` (SHA256
ba2c7118eba7fa7011202f70a54de26996b4dfbeb52e617b3f3711c2f4c09dc3).
The previous package was moved to `~/ros2_ws/backups/rm_flatness_nav_20261025_232931`.
No direct SDK connection or camera capture is opened by this package.

User-approved hardware adjustment (2026-10-26): arm X=105 mm, Y=80 mm.
The user reports that the assignment position X=105 mm, Y=30 mm blocks
the front ToF; Y=80 mm leaves it clear. This explicitly replaces the original
30 mm target. Physical clearance and reachability have not been tested here.

```bash
source /opt/ros/jazzy/setup.bash
source ~/rm_venv/bin/activate
source ~/ros2_ws/install/setup.bash
cd ~/ros2_ws
python3 -m colcon build --symlink-install --packages-select rm_flatness_nav
source install/setup.bash
```

First run with the robot connected by AP Wi-Fi, stationary, with clear space:

```bash
ros2 launch rm_flatness_nav assessment2.launch.py enable_motion:=false
```

This starts the single robomaster_ros driver, camera viewer, and logging node;
it sends only zero chassis commands and does not move the arm. Check the live
image, calibration, ToF and odometry. Stop with Ctrl-C before the active run:

```bash
ros2 launch rm_flatness_nav assessment2.launch.py
```

The node collects initial arm feedback and sends one absolute X=105 mm, Y=80 mm
move (ROS X/Z in metres). The driver waits up to 12 seconds for action completion.
Fresh measured arm feedback within 3 mm of the target gates chassis motion,
independently of the action result. The readiness log includes measured X/Y.
Once required interfaces are ready, navigation starts searching. A complete
odometry-measured turn without finding the tag triggers forward motion along the
current heading at 0.1 m/s for 5 seconds, then another search turn. This repeats
until alignment begins. Alignment immediately cancels the forward segment.
Lost required sensor data or arm readiness causes zero commands.
`view_camera:=false` supports a terminal without a graphical display.
`tag_size:=0.15` is the black tag square side length in metres, excluding margin.

## Installed driver interfaces inspected

All names below are relative to the root namespace; launch explicitly sets an
empty driver name to prevent RM_NAME from silently changing the interfaces.

| Interface | Type | Driver source |
| --- | --- | --- |
| camera/image_color | sensor_msgs/Image, bgr8 | modules/camera.py |
| camera/camera_info | sensor_msgs/CameraInfo | modules/camera.py |
| range_0 | sensor_msgs/Range, metres | modules/tof.py |
| cmd_vel | geometry_msgs/Twist, m/s and rad/s | modules/chassis.py |
| move_arm | robomaster_msgs/action/MoveArm | modules/arm.py |
| arm_position | geometry_msgs/PointStamped, metres, arm_base_link | modules/arm.py |
| odom | nav_msgs/Odometry | modules/chassis.py |

Sources are under `~/ros2_ws/src/robomaster_ros/robomaster_ros/robomaster_ros/`.
`target_arm_position` actually exists in this installation; the action is used
instead because it provides acceptance/completion status. SDK X=105 mm,Y=80 mm
maps to ROS action x=0.105,z=0.080,relative=false. Y in SDK is vertical; ROS Y is
lateral. The action documentation warns that success can mean closest reachable
position, so `arm_position` is checked separately.

`ep.launch` includes `main.launch`: AP is fixed, `tof_0=true`, `arm=true`,
`camera=true`, `video_raw=1`, robot description enabled. The driver receives ROS
angular velocity in radians and performs its own SDK conversion. Its supported
`chassis_timeout=0.45` stops a command that is not refreshed. A zero Twist is the
normal braking command; physical stopping performance requires a hardware test.

Camera frame is taken from CameraInfo and must match Image. The EP URDF mounts
camera_link on arm_2_link (rpy 0,1.6898531,camera_yaw), then camera_optical_link
(rpy 0.041623,0,-pi/2). There is no justified fixed 20 degree camera pitch.
Live base_link <- camera_optical_link TF (including the arm joints) rotates and
translates solvePnP's calibrated optical position before horizontal distance and
bearing are calculated. The newest transform must be fresh; using it avoids
extrapolating image stamps beyond the latest 10 Hz arm joint update. Physical
camera mounting and calibration accuracy still require checking on the robot.
The supplied driver calibration YAML is loaded by the driver; it is not replaced
by guessed intrinsics. ToF index 0 is enabled, but its physical front mounting
and sensor index must be confirmed on hardware (the URDF's default position is
0,0,0).

## Corrections to the reference

* Split the supplied merged reference into its original five modules and add
  explicit relative imports.
* Keep numpy.linalg.solve cubics, inversion, horizon, wheel equations, motor
  constants, alignment settle/realignment behaviour and pursuit gains.
* Default tag size 0.15 m; preserve ArUco AprilTag corner refinement and 1x/2x
  processing. Use the ROS stream only. cap.grab()/10 ms is relevant to a capture
  owner; adding it here would create a second camera connection.
* Use actual TF geometry, including camera translation, instead of a guessed
  fixed pitch; require live inputs before navigation.
* Disable the blind-chase extension because loss must cause SEARCHING after
  0.45 seconds. Use the original detection timestamp rather than extending it
  every tick during the 0.20-second detection-freshness window.
* Trajectory expiry alone cannot prove arrival. If the tag remains beyond 20 cm,
  replan the same cubic; if unavailable, search. Camera/ToF <=0.20 m latches
  ARRIVED and zeros. The original >0.30 rad chase realignment extension remains.
* Replace repeated arm topic sends with one action and verified feedback.
  Encode the next float32 above 0.105/0.080 to compensate for this driver's
  int(request.x*1000) truncation: the resulting hardware targets are exactly
  105 and 80 mm. Ordinary float32 serialization otherwise produces 104/79 mm.
* Flush both CSV streams. Log the first braking voltage estimate as well as the
  final stopped estimate; the original three stop ticks otherwise hid the
  deceleration term in the slow CSV.

## Logs and verification

Default outputs (overwritten on each run):

* `~/ros2_ws/log/assessment2/motor_voltage_log.csv`: four estimated voltages,
  state, command, distance, bearing, ToF and wheel rates at 1 Hz, plus braking and
  final-arrival records.
* `~/ros2_ws/log/assessment2/motor_voltage_fast.csv`: the friend's 20 Hz command
  and estimated motor voltage CSV for plots.

These are model estimates, not measured motor terminal voltages. First model
sample assumes zero acceleration, as in the reference. Set ROS parameters
`csv_path` and `fast_csv_path` when running the node directly to change paths.
The merged file is generated from the same five modules, not a separate
implementation. Do not run it concurrently with the launch navigation node.

Offline regression checks:

```bash
python3 ~/ros2_ws/src/rm_flatness_nav/test/test_assessment.py
```

See `VERIFICATION.md` for recorded results and hardware limitations.
